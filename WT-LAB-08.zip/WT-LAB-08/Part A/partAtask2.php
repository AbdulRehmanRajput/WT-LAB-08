<?php
function powerfun($number,$power){
	
$answer=1;
for ($i=1; $i<=$power; $i++)
{
	
	$answer = $answer * $number;
}
return $answer;
}
print "4 raise to power 7 is:".powerfun(4,7);






?>