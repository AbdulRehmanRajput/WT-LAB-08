<?php

function findfactorial($number)
{	
	if($number <= 1)

{ return 1;}
else
{
	return $number * findfactorial($number-1);
}
}
print "Factorial of 9 is ".findfactorial(9);
?>