<?php
function digits_in_word($digit)
{
    switch ($digit)
    {
        case "0":
            return "zero";
        case "1":
            return "one";
        case "2":
            return "two";
        case "3":
            return "three";
        case "4":
            return "four";
        case "5":
            return "five";
        case "6":
            return "six";
        case "7":
            return "seven";
        case "8":
            return "eight";
        case "9":
            return "nine";
    }}
$int=98652341;
$array = str_split($int);
$count=sizeof($array);
for($i=0; $i<$count; $i++){
	print " ".digits_in_word($array[$i]);
}

?>