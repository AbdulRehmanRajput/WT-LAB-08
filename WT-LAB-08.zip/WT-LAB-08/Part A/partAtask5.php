<?php 

function Checkarmstrong($number){ 
    $sum = 0;   
    $x = $number;   
    while($x != 0)   
    {   
        $rem = $x % 10;   
        $sum = $sum + $rem*$rem*$rem;   
        $x = $x / 10;   
    }   
      
    
    if ($number == $sum) {
        return 1; 
    }
      
    else {  
    return 0;     
} 
}
  

$number = 153; 
$flag = Checkarmstrong($number); 
if ($flag == 1) 
    echo " Yes.Your number is an Armstrong"; 
else
    echo "No.Your number is not an Armstrong"
?> 