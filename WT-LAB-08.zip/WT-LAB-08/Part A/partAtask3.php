<?php
function sum($num1=null,$num2=null,$num3=null)
{
 $sum = $num1 + $num2 + $num3;
 return $sum;
}

echo " Sum of 30,40,50 is ".sum(30,40,50);
echo "<br>";

function multiply($num1=null,$num2=null)
{
 $multiply = $num1 * $num2;
 return $multiply;
}

echo " Multiplication is ".multiply(20,30);
echo "<br>";

function subtract($num1=null,$num2=null,$num3=null)
{
 $subtract = $num1 - $num2 - $num3;
 return $subtract;
}

echo " Subtraction is ".subtract(100,70,20);
echo "<br>";


function division($num1=null,$num2=null)
{
 $div = $num1 / $num2;
 return $div;
}
echo " Division is ".division(90,3);
  
?>