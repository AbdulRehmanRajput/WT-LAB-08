<html>
<head>
</head>
<body>

  <form method="POST" >
   <input id="t" type="text" placeholder="Enter Email" name="email" required><br>
   <input id="b" type="submit" value="submit" name="valid">
  </form>

 <?php




if(array_key_exists('valid',$_POST)){ 
  $email = $_POST['email'];

  if(strlen($email) > 20){
     echo"More than 20 characters are not allowed..!"; }

  else{

  $var1 = explode('@', $email);

  if (sizeof($var1) > 2)
    echo "Email  contains only \"@\" - Try Again!";
  elseif(sizeof($var1) <= 1 )
    echo "Email must contain \"@\" - Try Again! ";

  else{

    if( is_numeric(substr($var1[0], 0, 1)))
      echo "First character should be Alphabet!";

    else{
      
      if(preg_match('/\s/', $email))
        echo "Spaces are not allowed...!";

      else{
        
        $var2 = explode(".", $email);
        if(sizeof($var2) > 3)
          echo "only use .com, .edu.pk, or co.uk instead.";
        elseif(sizeof($var2) <= 1)
          echo "Incorrect Domain..! - Try Again!";
        elseif(sizeof($var2) == 2){
          if($var2[1] == "com"){
            echo "<b>Email Is Correct!</b>";
          }
          else
            echo " u can only use .com, .edu.pk, or co.uk instead.";
        }
        elseif(sizeof($var2) == 3){
          if($var2[1] == "edu" && $var2[2] == "pk")
            echo "<b>Email Is Correct!</b>";
          elseif($var2 == "co" && $var2 == "uk")
            echo "<b>Email Is Correct!</b>";
          else{
            echo "only use .com, .edu.pk, or co.uk instead.";
          }

        }

      }

    }

}

} 
}


?>



</body>
</html>