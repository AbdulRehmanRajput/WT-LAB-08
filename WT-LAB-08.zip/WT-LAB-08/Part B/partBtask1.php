<html>
<head>
	<title> Form </title>

</head>
<body>

  <form method= "post" >

  	 
  	 NAME: <input type="text" placeholder="enter name"  name = "name"> 
  	 <br>
  	 PHONE NO:<input type="number" placeholder="Enter " name="number"> <br>

  	 <input type="submit" name="submit">

  </form>

  <?php

  if (array_key_exists('submit',$_POST)) {
  	  $name = $_POST['name'];
      $number = $_POST['number'];

      echo "Name : $name <br>"."Phone Number: $number"; 
    
  }
  ?>

</body>
</html>